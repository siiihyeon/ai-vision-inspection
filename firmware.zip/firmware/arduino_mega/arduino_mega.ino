#include <AccelStepper.h>
#include <Servo.h>

// ============================================================
// AI Vision Inspection - Arduino Mega Firmware
//
// Workflow
// 1) HC-SR04 #1 detects product
//    -> report SENSOR_1
//    -> Conveyor 1 automatically moves a fixed number of steps
//    -> stop at camera position
//    -> report POSITION settled
//
// 2) Master finishes capture
//    -> Control Node sends RUN|1
//    -> Conveyor 1 resumes
//
// 3) HC-SR04 #2 does the same thing for Conveyor 2.
//
// 4) HC-SR04 #3 only reports product arrival.
//    -> Conveyor 2 does NOT stop.
//
// 5) Control Node sends ACTUATE|1 for defective product.
//    -> continuous-rotation MG996R reject cycle runs non-blocking.
//    ACTUATE|2 = normal/pass, no servo motion.
//
// Serial framing is compatible with the existing CRC protocol:
//   C|seq|COMMAND|...|CRC
//   A|seq|OK|CRC
//   E|...|CRC
// ============================================================


// ============================================================
// 1. Pin map
//    Conveyor and Sensor 1 / Servo pins are copied from the
//    component-test sketches supplied by the project.
// ============================================================

// Conveyor 1 - tested pin map
#define CONV1_STEP 10
#define CONV1_DIR   9
#define CONV1_EN    8

// Conveyor 2 - tested pin map
#define CONV2_STEP  5
#define CONV2_DIR   4
#define CONV2_EN    3

// HC-SR04 #1 - tested pin map
#define TRIG1 7
#define ECHO1 6

// HC-SR04 #2
// TODO: change these two values if your actual wiring is different.
#define TRIG2 12
#define ECHO2 11

// HC-SR04 #3
// TODO: change these two values if your actual wiring is different.
#define TRIG3 14
#define ECHO3 15

// MG996R - tested pin map
#define SERVO_PIN 44


// ============================================================
// 2. Conveyor parameters
// ============================================================

AccelStepper conveyor1(AccelStepper::DRIVER, CONV1_STEP, CONV1_DIR);
AccelStepper conveyor2(AccelStepper::DRIVER, CONV2_STEP, CONV2_DIR);

// Values confirmed in the component-test sketch.
const long CONV1_SPEED = -3000;
const long CONV2_SPEED = -3000;

const long CONV_MAX_SPEED = 10000;
const long CONV_ACCELERATION = 10000;

// Component-test code actually used 7700 steps.
// Keep each conveyor independent because the required camera offset
// may be different after final mechanical assembly.
const long CONV1_CAMERA_OFFSET_STEPS = 7700;

// TODO: calibrate this value for the lower conveyor.
// 7700 is only a safe initial value copied from the upper test.
const long CONV2_CAMERA_OFFSET_STEPS = 7700;


// ============================================================
// 3. Ultrasonic parameters
// ============================================================

// Detection / release thresholds copied from servo_ultra.ino.
const float DETECT_DISTANCE_CM  = 10.0f;
const float RELEASE_DISTANCE_CM = 12.0f;

// Ping one sensor every 20 ms.
// With 3 sensors, each individual sensor is measured about every 60 ms.
// This also reduces ultrasonic crosstalk compared with triggering all
// three sensors at once.
const unsigned long GLOBAL_PING_INTERVAL_US = 20000UL;

// Same timeout used in the test sketches.
const unsigned long ECHO_TIMEOUT_US = 5000UL;

// Reject obviously invalid readings.
const float MIN_VALID_DISTANCE_CM = 1.5f;
const float MAX_VALID_DISTANCE_CM = 80.0f;


// ============================================================
// 4. Servo parameters
//    These values preserve the successful continuous-rotation test.
// ============================================================

Servo sorterServo;

const int SERVO_STOP    = 90;
const int SERVO_FORWARD = 150;
const int SERVO_REVERSE = 50;

const unsigned long SERVO_MOVE_TIME_MS = 3000UL;
const unsigned long SERVO_WAIT_TIME_MS = 500UL;


// ============================================================
// 5. Conveyor state machines
// ============================================================

enum ConveyorState : uint8_t {
  CONV_RUNNING = 0,
  CONV_POSITIONING,
  CONV_WAIT_CAMERA,
  CONV_STOPPED
};

struct ConveyorController {
  AccelStepper* motor;
  uint8_t enablePin;
  long runSpeed;
  long cameraOffsetSteps;
  uint8_t conveyorId;
  ConveyorState state;
  long positionCommandSequence;
  long positionTargetSteps;
};

ConveyorController conveyors[2] = {
  { &conveyor1, CONV1_EN, CONV1_SPEED, CONV1_CAMERA_OFFSET_STEPS, 1, CONV_RUNNING, 0, 0 },
  { &conveyor2, CONV2_EN, CONV2_SPEED, CONV2_CAMERA_OFFSET_STEPS, 2, CONV_RUNNING, 0, 0 }
};


// ============================================================
// 6. Ultrasonic state machine
// ============================================================

struct UltrasonicSensor {
  uint8_t trigPin;
  uint8_t echoPin;
  uint8_t sensorId;

  bool detectionArmed;
  uint32_t detectionSequence;
  float lastDistanceCm;
};

UltrasonicSensor sensors[3] = {
  { TRIG1, ECHO1, 1, true, 0, -1.0f },
  { TRIG2, ECHO2, 2, true, 0, -1.0f },
  { TRIG3, ECHO3, 3, true, 0, -1.0f }
};

enum SonicState : uint8_t {
  SONIC_IDLE = 0,
  WAIT_ECHO_HIGH,
  WAIT_ECHO_LOW
};

SonicState sonicState = SONIC_IDLE;

uint8_t activeSensorIndex = 0;
uint8_t nextSensorIndex = 0;

unsigned long lastGlobalPingUs = 0;
unsigned long pingStartUs = 0;
unsigned long echoStartUs = 0;


// ============================================================
// 7. Servo state machine
// ============================================================

enum ServoState : uint8_t {
  SERVO_READY = 0,
  SERVO_FORWARD_MOVE,
  SERVO_WAITING,
  SERVO_REVERSE_MOVE
};

ServoState servoState = SERVO_READY;
unsigned long servoStateStartMs = 0;


// ============================================================
// 8. Serial protocol
// ============================================================

const uint16_t PROTOCOL_VERSION = 2;
const unsigned long SERIAL_BAUD = 115200UL;

char rxBuffer[160];
size_t rxLength = 0;


// ============================================================
// CRC-16/CCITT-FALSE
// poly=0x1021, init=0xFFFF
// ============================================================

uint16_t crc16Ccitt(const char* text) {
  uint16_t crc = 0xFFFF;

  while (*text) {
    crc ^= ((uint16_t)(uint8_t)(*text++)) << 8;

    for (uint8_t i = 0; i < 8; ++i) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc <<= 1;
      }
    }
  }

  return crc;
}


void sendFrame(const char* body) {
  uint16_t crc = crc16Ccitt(body);

  Serial.print(body);
  Serial.print('|');

  char crcText[5];
  snprintf(crcText, sizeof(crcText), "%04X", crc);
  Serial.println(crcText);
}


void acknowledge(long sequence, const char* status) {
  char body[64];
  snprintf(body, sizeof(body), "A|%ld|%s", sequence, status);
  sendFrame(body);
}


void sendSensorEvent(uint8_t sensorId, uint32_t sensorSequence) {
  // Format retained from the existing Control Node protocol:
  // E|SENSOR|SENSOR_n|edge|sensor_sequence|estimated_step
  char body[96];
  snprintf(
    body,
    sizeof(body),
    "E|SENSOR|SENSOR_%u|1|%lu|0",
    sensorId,
    (unsigned long)sensorSequence
  );
  sendFrame(body);
}


void sendPositionSettled(uint8_t conveyorId, long movedSteps) {
  // E|POSITION|conveyor_id|step_count|position_command_sequence
  char body[96];
  ConveyorController& conveyor = conveyors[conveyorId - 1];
  snprintf(
    body,
    sizeof(body),
    "E|POSITION|%u|%ld|%ld",
    conveyorId,
    movedSteps,
    conveyor.positionCommandSequence
  );
  sendFrame(body);
}


void sendActuationEvent(const char* status) {
  char body[64];
  snprintf(body, sizeof(body), "E|ACTUATION|%s", status);
  sendFrame(body);
}


// ============================================================
// 9. Conveyor control
// ============================================================

void enableConveyor(ConveyorController& conveyor) {
  // TB6600 enable polarity copied from the test code.
  digitalWrite(conveyor.enablePin, LOW);
}


void startContinuousRun(uint8_t index) {
  if (index > 1) return;

  ConveyorController& conveyor = conveyors[index];

  enableConveyor(conveyor);
  conveyor.motor->setSpeed(conveyor.runSpeed);
  conveyor.state = CONV_RUNNING;
}


void stopConveyor(uint8_t index) {
  if (index > 1) return;

  conveyors[index].state = CONV_STOPPED;
  // Motor stays enabled so the belt can hold position.
}


bool startAutomaticPosition(uint8_t index, long targetSteps, long commandSequence) {
  if (index > 1) return false;

  ConveyorController& conveyor = conveyors[index];

  // Positioning is explicitly owned by the host POSITION command.
  if (conveyor.state != CONV_RUNNING) {
    return false;
  }

  enableConveyor(conveyor);

  conveyor.motor->setCurrentPosition(0);

  // Both tested conveyor speeds are negative, so move in the same
  // physical direction by using a negative relative target.
  long signedOffset =
    (conveyor.runSpeed < 0) ? -labs(targetSteps) : labs(targetSteps);

  conveyor.motor->move(signedOffset);
  conveyor.motor->setMaxSpeed(labs(conveyor.runSpeed));
  conveyor.motor->setAcceleration(CONV_ACCELERATION);
  conveyor.positionCommandSequence = commandSequence;
  conveyor.positionTargetSteps = targetSteps;

  conveyor.state = CONV_POSITIONING;
  return true;
}


void updateConveyor(uint8_t index) {
  if (index > 1) return;

  ConveyorController& conveyor = conveyors[index];

  switch (conveyor.state) {
    case CONV_RUNNING:
      conveyor.motor->runSpeed();
      break;

    case CONV_POSITIONING:
      conveyor.motor->run();

      if (conveyor.motor->distanceToGo() == 0) {
        conveyor.state = CONV_WAIT_CAMERA;

        // The host command sequence correlates this event with one product.
        sendPositionSettled(
          conveyor.conveyorId,
          conveyor.positionTargetSteps
        );
      }
      break;

    case CONV_WAIT_CAMERA:
      // Hold position until Master -> Control -> RUN command arrives.
      break;

    case CONV_STOPPED:
      break;
  }
}


// ============================================================
// 10. Product detection handling
// ============================================================

void handleDetection(uint8_t sensorIndex, float distanceCm) {
  if (sensorIndex > 2) return;

  UltrasonicSensor& sensor = sensors[sensorIndex];

  // Rearm only after the previous object has physically moved away.
  if (distanceCm >= RELEASE_DISTANCE_CM) {
    sensor.detectionArmed = true;
    return;
  }

  if (distanceCm > DETECT_DISTANCE_CM || !sensor.detectionArmed) {
    return;
  }

  // Sensor 1 is associated with Conveyor 1.
  if (sensor.sensorId == 1) {
    if (conveyors[0].state != CONV_RUNNING) {
      return;
    }

    sensor.detectionArmed = false;
    ++sensor.detectionSequence;

    // Master owns positioning; this event only reports the sensor edge.
    sendSensorEvent(sensor.sensorId, sensor.detectionSequence);
    return;
  }

  // Sensor 2 is associated with Conveyor 2.
  if (sensor.sensorId == 2) {
    if (conveyors[1].state != CONV_RUNNING) {
      return;
    }

    sensor.detectionArmed = false;
    ++sensor.detectionSequence;

    sendSensorEvent(sensor.sensorId, sensor.detectionSequence);
    return;
  }

  // Sensor 3 only reports arrival.
  // It never changes Conveyor 2 state.
  if (sensor.sensorId == 3) {
    sensor.detectionArmed = false;
    ++sensor.detectionSequence;

    sendSensorEvent(sensor.sensorId, sensor.detectionSequence);
  }
}


// ============================================================
// 11. Non-blocking HC-SR04 scheduler
// ============================================================

void startPing(uint8_t sensorIndex) {
  UltrasonicSensor& sensor = sensors[sensorIndex];

  digitalWrite(sensor.trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(sensor.trigPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(sensor.trigPin, LOW);

  activeSensorIndex = sensorIndex;
  pingStartUs = micros();
  sonicState = WAIT_ECHO_HIGH;
}


void finishPing(float distanceCm) {
  UltrasonicSensor& sensor = sensors[activeSensorIndex];
  sensor.lastDistanceCm = distanceCm;

  if (
    distanceCm >= MIN_VALID_DISTANCE_CM &&
    distanceCm <= MAX_VALID_DISTANCE_CM
  ) {
    handleDetection(activeSensorIndex, distanceCm);
  }

  lastGlobalPingUs = micros();
  nextSensorIndex = (activeSensorIndex + 1) % 3;
  sonicState = SONIC_IDLE;
}


void abortPing() {
  lastGlobalPingUs = micros();
  nextSensorIndex = (activeSensorIndex + 1) % 3;
  sonicState = SONIC_IDLE;
}


void updateUltrasonicSensors() {
  unsigned long now = micros();
  UltrasonicSensor& sensor = sensors[activeSensorIndex];

  switch (sonicState) {
    case SONIC_IDLE:
      if (now - lastGlobalPingUs >= GLOBAL_PING_INTERVAL_US) {
        startPing(nextSensorIndex);
      }
      break;

    case WAIT_ECHO_HIGH:
      if (digitalRead(sensor.echoPin) == HIGH) {
        echoStartUs = micros();
        sonicState = WAIT_ECHO_LOW;
      }
      else if (now - pingStartUs > ECHO_TIMEOUT_US) {
        abortPing();
      }
      break;

    case WAIT_ECHO_LOW:
      if (digitalRead(sensor.echoPin) == LOW) {
        unsigned long durationUs = micros() - echoStartUs;
        float distanceCm = durationUs * 0.0343f / 2.0f;
        finishPing(distanceCm);
      }
      else if (now - echoStartUs > ECHO_TIMEOUT_US) {
        abortPing();
      }
      break;
  }
}


// ============================================================
// 12. Non-blocking MG996R reject cycle
// ============================================================

bool startRejectCycle() {
  if (servoState != SERVO_READY) {
    return false;
  }

  sorterServo.write(SERVO_FORWARD);
  servoState = SERVO_FORWARD_MOVE;
  servoStateStartMs = millis();

  return true;
}


void updateServo() {
  unsigned long now = millis();

  switch (servoState) {
    case SERVO_READY:
      break;

    case SERVO_FORWARD_MOVE:
      if (now - servoStateStartMs >= SERVO_MOVE_TIME_MS) {
        sorterServo.write(SERVO_STOP);
        servoState = SERVO_WAITING;
        servoStateStartMs = now;
      }
      break;

    case SERVO_WAITING:
      if (now - servoStateStartMs >= SERVO_WAIT_TIME_MS) {
        sorterServo.write(SERVO_REVERSE);
        servoState = SERVO_REVERSE_MOVE;
        servoStateStartMs = now;
      }
      break;

    case SERVO_REVERSE_MOVE:
      if (now - servoStateStartMs >= SERVO_MOVE_TIME_MS) {
        sorterServo.write(SERVO_STOP);
        servoState = SERVO_READY;

        sendActuationEvent("OK");
      }
      break;
  }
}


// ============================================================
// 13. Serial command parser
// ============================================================

bool verifyAndStripCrc(char* line) {
  char* lastSeparator = strrchr(line, '|');

  if (lastSeparator == nullptr) {
    return false;
  }

  *lastSeparator = '\0';
  const char* receivedCrcText = lastSeparator + 1;

  if (strlen(receivedCrcText) != 4) {
    return false;
  }

  uint16_t receivedCrc = (uint16_t)strtoul(receivedCrcText, nullptr, 16);
  uint16_t calculatedCrc = crc16Ccitt(line);

  return receivedCrc == calculatedCrc;
}


void handleCommand(char* line) {
  if (!verifyAndStripCrc(line)) {
    return;
  }

  char* savePtr = nullptr;

  char* type = strtok_r(line, "|", &savePtr);
  char* sequenceText = strtok_r(nullptr, "|", &savePtr);
  char* operation = strtok_r(nullptr, "|", &savePtr);

  if (
    type == nullptr ||
    sequenceText == nullptr ||
    operation == nullptr ||
    strcmp(type, "C") != 0
  ) {
    return;
  }

  long sequence = atol(sequenceText);

  // ----------------------------------------------------------
  // HELLO
  // C|seq|HELLO|2
  // ----------------------------------------------------------
  if (strcmp(operation, "HELLO") == 0) {
    char* versionText = strtok_r(nullptr, "|", &savePtr);

    if (
      versionText != nullptr &&
      atoi(versionText) == PROTOCOL_VERSION
    ) {
      acknowledge(sequence, "OK");
    } else {
      acknowledge(sequence, "ERR_VERSION");
    }
    return;
  }

  // ----------------------------------------------------------
  // RUN
  // C|seq|RUN|1
  // C|seq|RUN|2
  // ----------------------------------------------------------
  if (strcmp(operation, "RUN") == 0) {
    char* conveyorText = strtok_r(nullptr, "|", &savePtr);

    if (conveyorText == nullptr) {
      acknowledge(sequence, "ERR");
      return;
    }

    int conveyorId = atoi(conveyorText);

    if (conveyorId == 1 || conveyorId == 2) {
      startContinuousRun(conveyorId - 1);
      acknowledge(sequence, "OK");
    } else {
      acknowledge(sequence, "ERR");
    }
    return;
  }

  // ----------------------------------------------------------
  // STOP
  // C|seq|STOP|1
  // C|seq|STOP|2
  // ----------------------------------------------------------
  if (strcmp(operation, "STOP") == 0) {
    char* conveyorText = strtok_r(nullptr, "|", &savePtr);

    if (conveyorText == nullptr) {
      acknowledge(sequence, "ERR");
      return;
    }

    int conveyorId = atoi(conveyorText);

    if (conveyorId == 1 || conveyorId == 2) {
      stopConveyor(conveyorId - 1);
      acknowledge(sequence, "OK");
    } else {
      acknowledge(sequence, "ERR");
    }
    return;
  }

  // ----------------------------------------------------------
  // ACTUATE
  // 1 = NG / reject
  // 2 = PASS / no physical motion
  // ----------------------------------------------------------
  if (strcmp(operation, "ACTUATE") == 0) {
    char* commandText = strtok_r(nullptr, "|", &savePtr);

    if (commandText == nullptr) {
      acknowledge(sequence, "ERR");
      return;
    }

    int actuatorCommand = atoi(commandText);

    if (actuatorCommand == 1) {
      if (startRejectCycle()) {
        acknowledge(sequence, "OK");
      } else {
        acknowledge(sequence, "BUSY");
      }
    }
    else if (actuatorCommand == 2) {
      // Normal product: intentionally no servo motion.
      acknowledge(sequence, "OK");
      sendActuationEvent("OK");
    }
    else {
      acknowledge(sequence, "ERR");
    }
    return;
  }

  // ----------------------------------------------------------
  // Optional manual POSITION command.
  // Not used in the normal autonomous workflow.
  // Kept only for maintenance/backward compatibility.
  //
  // C|seq|POSITION|conveyor_id|steps
  // ----------------------------------------------------------
  if (strcmp(operation, "POSITION") == 0) {
    char* conveyorText = strtok_r(nullptr, "|", &savePtr);
    char* stepsText = strtok_r(nullptr, "|", &savePtr);

    if (conveyorText == nullptr || stepsText == nullptr) {
      acknowledge(sequence, "ERR");
      return;
    }

    int conveyorId = atoi(conveyorText);
    long steps = atol(stepsText);

    if (
      (conveyorId == 1 || conveyorId == 2) &&
      steps > 0
    ) {
      ConveyorController& conveyor = conveyors[conveyorId - 1];

      if (conveyor.state == CONV_RUNNING) {
        if (startAutomaticPosition(conveyorId - 1, steps, sequence)) {
          acknowledge(sequence, "OK");
        } else {
          acknowledge(sequence, "BUSY");
        }
      } else {
        acknowledge(sequence, "BUSY");
      }
    } else {
      acknowledge(sequence, "ERR");
    }
    return;
  }

  acknowledge(sequence, "ERR_COMMAND");
}


void updateSerial() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();

    if (c == '\r') {
      continue;
    }

    if (c == '\n') {
      if (rxLength > 0) {
        rxBuffer[rxLength] = '\0';
        handleCommand(rxBuffer);
        rxLength = 0;
      }
      continue;
    }

    if (rxLength < sizeof(rxBuffer) - 1) {
      rxBuffer[rxLength++] = c;
    } else {
      // Overflow: discard the incomplete frame.
      rxLength = 0;
    }
  }
}


// ============================================================
// 14. Arduino setup / main loop
// ============================================================

void setup() {
  Serial.begin(SERIAL_BAUD);

  // TB6600 enable pins
  pinMode(CONV1_EN, OUTPUT);
  pinMode(CONV2_EN, OUTPUT);

  digitalWrite(CONV1_EN, LOW);
  digitalWrite(CONV2_EN, LOW);

  // Conveyor parameters copied from the working test code.
  conveyor1.setMaxSpeed(CONV_MAX_SPEED);
  conveyor1.setAcceleration(CONV_ACCELERATION);
  conveyor1.setSpeed(CONV1_SPEED);

  conveyor2.setMaxSpeed(CONV_MAX_SPEED);
  conveyor2.setAcceleration(CONV_ACCELERATION);
  conveyor2.setSpeed(CONV2_SPEED);

  // HC-SR04
  for (uint8_t i = 0; i < 3; ++i) {
    pinMode(sensors[i].trigPin, OUTPUT);
    pinMode(sensors[i].echoPin, INPUT);
    digitalWrite(sensors[i].trigPin, LOW);
  }

  // Continuous-rotation MG996R behavior copied from the test code.
  sorterServo.attach(SERVO_PIN);
  sorterServo.write(SERVO_STOP);

  // Start both conveyors independently.
  conveyors[0].state = CONV_RUNNING;
  conveyors[1].state = CONV_RUNNING;

  // No plain-text Serial debug output here.
  // All PC-facing messages use CRC-framed protocol packets.
}


void loop() {
  // These functions are intentionally non-blocking so Conveyor 1,
  // Conveyor 2, ultrasonic sensing, serial communication and servo
  // rejection can progress independently.
  updateSerial();

  updateConveyor(0);
  updateConveyor(1);

  updateUltrasonicSensors();

  updateServo();
}